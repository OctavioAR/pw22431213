let mensaje = "hola javascript";
console.log(mensaje);
console.log(typeof(mensaje));

mensaje = 5;
console.log(mensaje);
console.log(typeof(mensaje));