let numeros: number;
numeros = 101;
console.log(numeros);
let arreglosNumeros: number[];
arreglosNumeros = [1,2,3,4,5,6];
let arregloString: string[];
arregloString = ["A","B","C","D"];
let decisiones: boolean;
decisiones = true;
let arreglosBooleanos: Boolean[];
arreglosBooleanos = [true, false, true];
function info(a:number,b:string,c:boolean,d?:number): void{//? parametro opcional
    console.log(a+" "+b+" "+c+" "+(d==undefined ? '-':d));
}
info(1,'2',false,10);
enum TipoUsuario{
    Administrador,
    Moderador,
    Invitado
}
type Usuario = {
    nombre:string, tipo:TipoUsuario, edad:boolean, readonly ipSecrerta: string
}
type UsuarioRedes = Usuario & { //extendiendo el tipo
    ip: string
}
function usuarios(usuario: UsuarioRedes):void{
    console.log("Nombre: "+usuario.nombre+" tipo: "+usuario.tipo+" edad: "+usuario.edad+" con la ip: "+usuario.ip+" "+usuario.ipSecrerta);
}
console.log(usuarios({nombre:'Octavio',tipo:TipoUsuario.Moderador,edad:true, ip:"192.168.4.1", ipSecrerta:"algo"}));


//Tipos que solo existen en Typescript
//el any significa que es cualquier tipo
let tiempo:number = 76_000_000;
let animal:string = 'dinosaurio';
let extinto:boolean = true;
//Tipo any
let mivariable;
mivariable = "CADENA";
mivariable = 42;

//Arreglos
let animales:string[] = ['perro','gato','caballo'];
let numeros1:number[] = [1,2,3,4,5];
let atributos:boolean[] = [];
let numeros2: Array<number> = [];

//animales.map(x => x.)

//Tuplas
let tupla:[number,string] = [1,'cadena'];
tupla.push(12); //no marca error
let tupla2:[number,string[]] = [1,['cadena','cadena2','cadena3']];

//Enums
const chica = 's';
const mediana = 'm';
const grande = 'l';
const extragrande = 'xl';

//enum Talla {Chica = 2,Mediana = 3,Grande = 4,Extragrande};
enum Talla {Chica = 's',Mediana = 'm',Grande = 'l',Extragrande = 'xl'};
const tallaGrande = Talla.Grande;
console.log("Talla: "+tallaGrande);

//Ponemos const para ocultar la enum del JS
const enum EstadoCargaPagina {Sininiciar, Cargando, Exito, Error};
//Solamente sale la asignacion del valor explicito en JS
const estado = EstadoCargaPagina.Exito;

//Objetos
const objeto:{
    readonly id:number,
    nombre:string
} = {id:1, nombre:''};
//objeto.id = 50; //el readonly se puede usar por ejemplo cuando tenemos el id de una BD
objeto.nombre = 'PW'
//? opcional
const objeto2:{id:number,nombre?:string} = {id:1};
objeto2.nombre = 'pw';

const objeto3:{id:number,nombre:string,talla:Talla} = {id:1,nombre:'PW',talla:Talla.Mediana};

type Persona = {
    id:number,
    nombre:string,
    talla:Talla
};

const objeto4:Persona = {id:1,nombre:'PW',talla:Talla.Extragrande};

type Direccion = {
    numero:number,
    calle:string,
    pais:string
};
type Persona2 = {
    id:number,
    nombre:string,
    talla:Talla,
    domicilio:Direccion
};

const objeto5:Persona2 = {id:1, nombre:'Octavio',talla:Talla.Chica,domicilio:{numero:1,calle:'conocida',pais:'Mexico'}};

//Tipado de funciones
function func(){}

const fn1 = (y:number): number=> {
    let x=2;
    if(x>5){
        return y;
    }
    return 4;
}

const fn2: () => number = () =>{
    let x=2;
    if(x>5){
        return 2;
    }
    return 4;
};

const fn3: (a:number) => string = (edad:number) =>{
    if(edad >= 18){
        return "Puedes pasar";
    }
    return "No puedes pasar";
};

//Never: Se usa cuando necesitamos que la funcion lance un error
function ErrorUsuario1(): void{
    throw new Error('error de usuario');
}
function ErrorUsuario12(): never{
    throw new Error('error de usuario');
}