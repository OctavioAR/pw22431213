import express from 'express';
//creamos la aplicacion a traves del paquete express
//y llamamos a su constructor
const app = express();
//Configurar rutas para el acceso personal
import personalRutas from './routes/personalRutas';

//Todo lo que regresa al usuario es tipo JSON
app.use(express.json());
//Puerto para escribir la petición del frontend
const PUERTO = 3001;
//Activar la ruta base
app.use('/api/personal',personalRutas);

/*app.get('/hola', (_req, res) =>{
    let fecha = new Date().toLocaleDateString();
    res.send('mundo con la fecha '+fecha+" con typescript");
});*/

//Encendemos el servidor y lo ponemos en escucha
app.listen(PUERTO, ()=>{
    console.log(`Servidor en ejecucion y escucha el puerto ${PUERTO}`);
});

//con packagephobia podemos verificar cuanto pesa nuestro proyecto

